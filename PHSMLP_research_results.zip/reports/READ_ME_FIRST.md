# FineWeb-Edu 500M-token × 4-model research audit

This is the compact audit bundle, NOT the token dataset or model checkpoints.
The dataset is HuggingFaceFW/fineweb-edu, config sample-10BT; see manifest
for resolved revision and tokenizer SHA-256. The experiment scores a frozen
set of 500M training next-token targets exactly once per model and uses
hash-separated validation and untouched final test text.

Four-way factorial design: standard, standard+pool, shared FFN, shared FFN+pool.
Three passes, four heads (computed in parallel), one 64-wide state, 256 FFN
hidden neurons; shared variants reuse the same FFN across three passes.
Pooling is an ADDED residual path, never a replacement for normal multi-head
attention. Pooling queries, projections and gates are trained end-to-end.

Main files:
- experiment_config.json / experiment_manifest.json / model_specs.json
- metrics/health.csv: each 1M-token milestone per model
- metrics/probe_milestones.csv: regular/full probe trajectories
- probes/validation/probe_rows.csv: all prompt-level outcomes
- probes/test/final_probe_rows.csv: held-out final prompt-level outcomes
- probes/pool_ablations.csv: uniform/shifted/off vs learned pooling
- probes/**/copying.csv: repeated-phrase copying vs matched controls
- reports/probe_preflight.json: checks every probe category and skipped conditions
- reports/final_results.json: final held-out language test results
- reports/paired_final_bootstrap.json: paired bootstrap differences
- research500.py: exact implementation and evaluation source

Caveats: synthetic binding/reasoning probes are zero-shot, not fine-tuning.
Four-choice accuracy has 25% nominal chance when probes are valid.
Per-case skipped prompts are tracked with reasons; do not silently discard them.
Token cache and checkpoints deliberately excluded from this ZIP (<350MB).
This is a single-seed pilot unless the full experiment is rerun with other seeds.
Ablation-at-evaluation measures dependence on learned pooling, NOT whether
pooling would help if another architecture were retrained without it.

Source: https://huggingface.co/datasets/HuggingFaceFW/fineweb-edu
Dataset licence noted by provider: ODC-BY. Review its original terms.
